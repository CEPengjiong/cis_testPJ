# -*- coding: utf-8 -*-
# @Time    : 2022/10/19 11:51
# @Author  : PengJiong
# @Email   : 18390050274@qq.com
# @File    : 404.py
from utils.random_phone import random_name,random_phone

name = random_name()
# print(name)