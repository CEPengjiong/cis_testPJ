# -*- coding: utf-8 -*-
# @Time    : 2022/8/29 16:44
# @Author  : PengJiong
# @Email   : 18390050274@qq.com
# @File    : __init__.py.py
import logging
import api_config
# 初始化日志
api_config.init_log()
