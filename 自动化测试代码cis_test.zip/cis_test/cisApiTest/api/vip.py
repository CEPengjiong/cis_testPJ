# -*- coding: utf-8 -*-
# @Time    : 2022/4/28 17:41
# @Author  : PengJiong
# @Email   : 18390050274@qq.com
# @File    : vip.py

import time
from utils.request_common import request_common
import datetime as DT
from utils.random_phone import random_phone,random_name
import api_config

phone = random_phone()
name = random_name()

endtime = DT.date.today()
beginTime = endtime - DT.timedelta(days=10)
t = time.time()
_t = int(t)

# 格式化成2021-09-13 11:45:39形式
visitTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

class vip:
    # 会员列表
    def vippage(self, moudle_name, case_name, request_method, url, data):
        url = url + str(_t) + "&pageNum=1&pageSize=10beginTime=&endTime="
        return request_common(moudle_name, case_name, request_method, url=url, data=data)

    # 新增会员
    def vipvip(self, moudle_name, case_name, request_method, url, data, phone, name):
        url = url + str(_t)
        data[0]["phone"] = phone
        data[0]["name"] = name
        return request_common(moudle_name, case_name, request_method, url=url, data=data)

    # 会员详情
    def logpage(self, moudle_name, case_name, request_method, url, data):
        url = url + str(_t) + "&pageNum=1&pageSize=10&vipId=10"
        return request_common(moudle_name, case_name, request_method, url=url, data=data)

    # def aaa(self, moudle_name, case_name, request_method, url, data):
    #     url = url +str(_t)
    #     return request_common(moudle_name, case_name, request_method, url=url, data=data)
    #
    # def bba(self, moudle_name, case_name, request_method, url, data):
    #     url = url +str(_t)
    #     return request_common(moudle_name, case_name, request_method, url=url, data=data)
    #
    # def bba(self, moudle_name, case_name, request_method, url, data):
    #     url = url +str(_t)
    #     return request_common(moudle_name, case_name, request_method, url=url, data=data)
    #
    # def bba(self, moudle_name, case_name, request_method, url, data):
    #     url = url +str(_t)
    #     return request_common(moudle_name, case_name, request_method, url=url, data=data)
    #
    # def bba(self, moudle_name, case_name, request_method, url, data):
    #     url = url +str(_t)
    #     return request_common(moudle_name, case_name, request_method, url=url, data=data)
    #
    # def bba(self, moudle_name, case_name, request_method, url, data):
    #     url = url +str(_t)
    #     return request_common(moudle_name, case_name, request_method, url=url, data=data)
    #
    # def bba(self, moudle_name, case_name, request_method, url, data):
    #     url = url +str(_t)
    #     return request_common(moudle_name, case_name, request_method, url=url, data=data)
    #
    # def bba(self, moudle_name, case_name, request_method, url, data):
    #     url = url +str(_t)
    #     return request_common(moudle_name, case_name, request_method, url=url, data=data)