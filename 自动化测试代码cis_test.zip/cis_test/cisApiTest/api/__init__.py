import logging
import api_config

# 初始化日志
api_config.init_log()
